# Control plan diff

No previous plan was given, so there is nothing to compare.
