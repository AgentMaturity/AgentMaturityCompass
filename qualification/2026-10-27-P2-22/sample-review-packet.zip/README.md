# AMC review packet

Packet: rp_105d3426a148f3e30669e7c6

Evidence of conformity, never a compliance statement. A signature proves who issued these bytes and that they are unchanged, not that they are true.

## Verify

1. Verify `attestation/review-packet.dsse.json` with `amc-verify` and the issuer key pinned in your trust list (`--trust-list`, `--trust-root`).
   Supply every other file of this packet as evidence: each subject digest must match the bytes you hold.
2. Public keys inside a packet only identify the signer. Never verify a packet with a key it ships: a forger can replace both.
3. `verifier/report.json` is the verifier's report when the packet was built, against the builder's trust list. Re-run it yourself.

## Contents

- `plan/`: the signed compiled plan, its catalog lockfile and the diff from the previous plan (reasons from the compiler).
- `results/`: control results with their claim kind and five status dimensions.
- `evidence/`: evidence references and payload hashes; no evidence content.
- `receipts/`: action receipts in the window.
- `exports/`: OSCAL documents and a PDF summary, when requested.
- `manifest.json`: every file and its sha256.
