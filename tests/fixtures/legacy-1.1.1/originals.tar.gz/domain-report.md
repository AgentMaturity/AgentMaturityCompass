# AMC Domain Report: Governance / Public Sector
Generated: 2026-10-16T16:58:25.784Z

## Executive Summary
- Domain: Governance / Public Sector
- Level: L3
- Certification Readiness: no
- Base Score: 69
- Domain Score: 64
- Composite Score: 67

## Module Activation Table
| Module ID | Module Name | Relevance | Status | Activation Reason |
|---|---|---|---|---|
| S10 | Injection Detector | critical | partial | Injection defense is mandatory to prevent instruction hijack across all regulated domains. |
| E15 | ABAC | critical | partial | ABAC enforces accountable access boundaries for public data and decisions. |
| E19 | Two-Person Auth | critical | partial | Policy-impacting citizen decisions require accountable dual control. |
| W3 | Audit / SIEM Export | critical | partial | Citizen-impacting decisions must be documented, reviewable, and contestable. |
| E20 | Payee Guard | high | partial | Government disbursement workflows require destination controls and evidence. |
| V4 | Trust-Boundary DLP | high | partial | Public-sector records and citizen data require boundary-level DLP enforcement. |
| V8 | Sovereignty Controls | high | partial | Public-sector records must align to jurisdictional sovereignty requirements. |
| W1 | Receipts | high | partial | Receipts supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| W2 | Assurance Runner | high | partial | Assurance Runner supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| W4 | Safety Testkit | high | partial | Safety Testkit supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| W5 | Equity Test Bus | high | partial | Disparate impact monitoring supports public-sector equity obligations. |
| W6 | Host Hardening | high | partial | Host Hardening supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| W7 | Explainability Packet | high | partial | Explainability Packet supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| W8 | Output Attestation | high | partial | Output Attestation supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| W9 | Multi-Tenant Verifier | high | partial | Multi-Tenant Verifier supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| W10 | Policy Pack Monitor | high | partial | Policy Pack Monitor supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P1 | Ab Testing | high | partial | Ab Testing supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P2 | Approval Workflow | high | partial | Approval Workflow supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P3 | Async Callback | high | partial | Async Callback supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P4 | Autonomy Dial | high | partial | Autonomy Dial supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P5 | Clarification | high | partial | Clarification supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P6 | Collaboration | high | partial | Collaboration supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P7 | Compensation | high | partial | Compensation supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P8 | Confidence | high | partial | Confidence supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P9 | Context Optimizer | high | partial | Context Optimizer supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P10 | Context Pack | high | partial | Context Pack supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P11 | Conversation State | high | partial | Conversation State supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P12 | Conversation Summarizer | high | partial | Conversation Summarizer supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P13 | Cost Latency Router | high | partial | Cost Latency Router supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P14 | Data Quality | high | partial | Data Quality supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P15 | Dependency Graph | high | partial | Dependency Graph supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P16 | Determinism | high | partial | Determinism supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P17 | Dev Sandbox | high | partial | Dev Sandbox supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P18 | Docs Ingestion | high | partial | Docs Ingestion supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P19 | Document Assembler | high | partial | Document Assembler supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P20 | Error Translator | high | partial | Error Translator supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P21 | Escalation | high | partial | Escalation supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P22 | Event Router | high | partial | Event Router supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P23 | Extractor | high | partial | Extractor supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P24 | Failure Clustering | high | partial | Failure Clustering supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P25 | Feature Catalog | high | partial | Feature Catalog supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P26 | Fix Generator | high | partial | Fix Generator supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P27 | Glossary | high | partial | Glossary supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P28 | Goal Tracker | high | partial | Goal Tracker supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P29 | Improvement | high | partial | Improvement supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P30 | Instruction Formatter | high | partial | Instruction Formatter supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P31 | Jobs | high | partial | Jobs supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P32 | Kb Builder | high | partial | Kb Builder supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P33 | Knowledge Graph | high | partial | Knowledge Graph supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P34 | Long Term Memory | high | partial | Long Term Memory supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P35 | Loop Detector | high | partial | Loop Detector supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P36 | Memory Consolidation | high | partial | Memory Consolidation supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P37 | Metering | high | partial | Metering supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P38 | Onboarding Wizard | high | partial | Onboarding Wizard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P39 | Outcome Pricing | high | partial | Outcome Pricing supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P40 | Output Corrector | high | partial | Output Corrector supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P41 | Output Diff | high | partial | Output Diff supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P42 | Param Autofiller | high | partial | Param Autofiller supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P43 | Persistence | high | partial | Persistence supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P44 | Persona | high | partial | Persona supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P45 | Plan Generator | high | partial | Plan Generator supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P46 | Proactive Reminders | high | partial | Proactive Reminders supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P47 | Prompt Modules | high | partial | Prompt Modules supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P48 | Reasoning Coach | high | partial | Reasoning Coach supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P49 | Replay Debugger | high | partial | Replay Debugger supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P50 | Response Validator | high | partial | Response Validator supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P51 | Retention Autopilot | high | partial | Retention Autopilot supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P52 | Retry Engine | high | partial | Retry Engine supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P53 | Rollout Manager | high | partial | Rollout Manager supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P54 | Scaffolding | high | partial | Scaffolding supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P55 | Scratchpad | high | partial | Scratchpad supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P56 | Sop Compiler | high | partial | Sop Compiler supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P57 | Structured Output | high | partial | Structured Output supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P58 | Sync Connector | high | partial | Sync Connector supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P59 | Task Spec | high | partial | Task Spec supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P60 | Task Splitter | high | partial | Task Splitter supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P61 | Tool Chain Builder | high | partial | Tool Chain Builder supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P62 | Tool Contract | high | partial | Tool Contract supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P63 | Tool Cost Estimator | high | partial | Tool Cost Estimator supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P64 | Tool Discovery | high | partial | Tool Discovery supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P65 | Tool Fallback | high | partial | Tool Fallback supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P66 | Tool Parallelizer | high | partial | Tool Parallelizer supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P67 | Tool Rate Limiter | high | partial | Tool Rate Limiter supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P68 | Tool Reliability | high | partial | Tool Reliability supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P69 | Tool Semantic Docs | high | partial | Tool Semantic Docs supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P70 | Version Control | high | partial | Version Control supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P71 | White Label | high | partial | White Label supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P72 | Workflow Engine | high | partial | Workflow Engine supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P73 | Workflow Templates | high | partial | Workflow Templates supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P74 | Agent Persona Safety | high | partial | Agent Persona Safety supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P75 | Cross Domain Policy Router | high | partial | Cross Domain Policy Router supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P76 | Domain Risk Telemetry | high | partial | Domain Risk Telemetry supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P77 | Governance Workflow Studio | high | partial | Governance Workflow Studio supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P78 | Human Review Queue | high | partial | Human Review Queue supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P79 | Incident Timeline Builder | high | partial | Incident Timeline Builder supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P80 | Knowledge Freshness Tracker | high | partial | Knowledge Freshness Tracker supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P81 | Latency Budget Planner | high | partial | Latency Budget Planner supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P82 | Market Anomaly Detector | high | partial | Market Anomaly Detector supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P83 | Model Drift Forecaster | high | partial | Model Drift Forecaster supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P84 | Portfolio Suitability Engine | high | partial | Portfolio Suitability Engine supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P85 | Procurement Compliance Kit | high | partial | Procurement Compliance Kit supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P86 | Regulatory Citation Resolver | high | partial | Regulatory Citation Resolver supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P87 | Remediation Planner | high | partial | Remediation Planner supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P88 | Safety Case Assembler | high | partial | Safety Case Assembler supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P89 | Transparency Dashboard | high | partial | Transparency Dashboard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| P90 | Zero Trust Session Broker | high | partial | Zero Trust Session Broker supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S1 | Static Analyzer | medium | active | Static Analyzer supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S2 | Behavioral Sandbox | medium | active | Behavioral Sandbox supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S3 | Signing & Provenance | medium | active | Signing & Provenance supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S4 | SBOM Integrity | medium | active | SBOM Integrity supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S5 | Reputation Guard | medium | active | Reputation Guard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S6 | Manifest Validator | medium | active | Manifest Validator supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S7 | Registry Trust | medium | active | Registry Trust supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S8 | Ingress Filter | medium | active | Ingress Filter supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S9 | Content Sanitizer | medium | active | Content Sanitizer supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S11 | Attachment Detonation | medium | active | Attachment Detonation supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S12 | OAuth Scope Guard | medium | active | OAuth Scope Guard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S13 | Download Quarantine | medium | active | Download Quarantine supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S14 | Conversation Integrity | medium | active | Conversation Integrity supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S15 | Threat Intelligence | medium | active | Threat Intelligence supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| S16 | UI Fingerprinting | medium | active | UI Fingerprinting supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E1 | Policy Firewall | medium | active | Policy Firewall supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E2 | Exec Guard | medium | active | Exec Guard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E3 | Browser Guardrails | medium | active | Browser Guardrails supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E4 | Egress Proxy | medium | active | Egress Proxy supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E5 | Circuit Breaker | medium | active | Circuit Breaker supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E6 | Step-Up Auth | medium | active | Step-Up Auth supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E7 | Sandbox Orchestrator | medium | active | Sandbox Orchestrator supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E8 | Session Firewall | medium | active | Session Firewall supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E9 | Outbound Filter | medium | active | Outbound Filter supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E10 | Gateway Scanner | medium | active | Gateway Scanner supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E11 | mDNS Controller | medium | active | mDNS Controller supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E12 | Reverse Proxy Guard | medium | active | Reverse Proxy Guard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E13 | ATO Detection | medium | active | ATO Detection supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E14 | Webhook Gateway | medium | active | Webhook Gateway supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E16 | Approval Anti-Phishing | medium | active | Approval Anti-Phishing supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E17 | Dry Run | medium | active | Dry Run supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E18 | Secret Blind | medium | active | Secret Blind supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E21 | Taint Tracker | medium | active | Taint Tracker supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E22 | Schema Gate | medium | active | Schema Gate supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E23 | Numeric Checker | medium | active | Numeric Checker supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E24 | Evidence Contract | medium | active | Evidence Contract supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E25 | Config Linter | medium | active | Config Linter supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E26 | Mode Switcher | medium | active | Mode Switcher supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E27 | Temporal Controls | medium | active | Temporal Controls supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E28 | Geo-Fence | medium | active | Geo-Fence supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E29 | Idempotency | medium | active | Idempotency supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E30 | Cross-Source Verifier | medium | active | Cross-Source Verifier supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E31 | Clipboard Guard | medium | active | Clipboard Guard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E32 | Template Engine | medium | active | Template Engine supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E33 | Watchdog | medium | active | Watchdog supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E34 | Consensus | medium | active | Consensus supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| E35 | Model Switchboard | medium | active | Model Switchboard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V1 | Secrets Broker | medium | active | Secrets Broker supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V2 | DLP | medium | active | DLP supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V3 | Honeytokens | medium | active | Honeytokens supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V5 | Memory TTL | medium | active | Memory TTL supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V6 | DSAR Autopilot | medium | active | DSAR Autopilot supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V7 | Data Residency | medium | active | Data Residency supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V9 | Invoice Fraud Guard | medium | active | Invoice Fraud Guard supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V10 | Undo Layer | medium | active | Undo Layer supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V11 | Metadata Scrubber | medium | active | Metadata Scrubber supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V12 | Data Classification | medium | active | Data Classification supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V13 | Privacy Budget | medium | active | Privacy Budget supports public accountability, explainability, and non-discrimination controls in this domain profile. |
| V14 | Key Rotation | medium | active | Key Rotation supports public accountability, explainability, and non-discrimination controls in this domain profile. |

## Compliance Gap Analysis
### EU AI Act Art.13, GDPR Art.22
| Question | Dimension | Current | Required | Remediation |
|---|---|---|---|---|
| GOV-6 | Transparency & Explainability | L2 | L3 | Raise GOV-6 from L2 to L3. Implement evidence for Transparency & Explainability and capture: Citizen-facing explanation artifacts and review logs. |

### EU AI Act Art.5 prohibited uses
| Question | Dimension | Current | Required | Remediation |
|---|---|---|---|---|
| GOV-4 | Democratic Safeguards | L3 | L4 | Raise GOV-4 from L3 to L4. Implement evidence for Democratic Safeguards and capture: Abuse prevention controls and audit evidence. |

### Executive Order 13985, EU AI Act Art.10
| Question | Dimension | Current | Required | Remediation |
|---|---|---|---|---|
| GOV-5 | Equity & Non-Discrimination | L2 | L3 | Raise GOV-5 from L2 to L3. Implement evidence for Equity & Non-Discrimination and capture: Disparate impact audits and remediation plans. |

## 30/60/90-Day Roadmap
| Priority | Timeframe | Action | Module | Regulatory Impact |
|---|---|---|---|---|
| 1 | 30d | Close compliance gap GOV-4: Raise GOV-4 from L3 to L4. Implement evidence for Democratic Safeguards and capture: Abuse prevention controls and audit evidence. | W3 | EU AI Act Art.5 prohibited uses |
| 2 | 60d | Close compliance gap GOV-5: Raise GOV-5 from L2 to L3. Implement evidence for Equity & Non-Discrimination and capture: Disparate impact audits and remediation plans. | E15 | Executive Order 13985, EU AI Act Art.10 |
| 3 | 90d | Close compliance gap GOV-6: Raise GOV-6 from L2 to L3. Implement evidence for Transparency & Explainability and capture: Citizen-facing explanation artifacts and review logs. | W1 | EU AI Act Art.13, GDPR Art.22 |

## Regulatory Warnings
- Moderate risk in GOV-4 against EU AI Act Art.5 prohibited uses.
- Elevated risk in GOV-5 against Executive Order 13985, EU AI Act Art.10.
- Elevated risk in GOV-6 against EU AI Act Art.13, GDPR Art.22.
